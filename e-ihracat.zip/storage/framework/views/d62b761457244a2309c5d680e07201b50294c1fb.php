
<!DOCTYPE html>
<!--[if IE 7]><html class="ie ie7 ltie8 ltie9" lang="en-US"><![endif]-->
<!--[if IE 8]><html class="ie ie8 ltie9" lang="en-US"><![endif]-->
<!--[if !(IE 7) | !(IE 8)  ]><!-->
<html lang="<?php echo e(app()->getLocale()); ?>">
<!--<![endif]-->

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <input type="hidden" id="meta_csrf"  value="<?php echo e(csrf_token()); ?>">
    <?php if($page): ?>
        <title><?php echo e($page->seo_title); ?></title>
        <meta name="description" content="<?php echo e($page->seo_description); ?>"/>
    <?php else: ?>
        <title>test</title>
        <meta name="description" content="test"/>
<?php endif; ?>
<?php /**PATH C:\Users\ylmzb\Desktop\e-ihracat\resources\views/inc/head.blade.php ENDPATH**/ ?>