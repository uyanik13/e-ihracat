﻿<?php
    $posts = Helper::getAllBlogs();
    $HomeUnderMenuSlider = Helper::findCustomData('HomeUnderMenuSlider');
    $about = Helper::findCustomData('about');
    $QuickServiceList = Helper::findCustomData('QuickServiceList');
    $fourBox = Helper::findCustomData('fourBox');
    $findServiceswithoutId = Helper::findServiceswithoutId();
    $randomPartners = Helper::randomPartners();
    $faqs = Helper::findCustomData('Faq');
?>
<!-- Header End -->


<!-- Content Start -->
<div id="contentWrapper">

    <!-- Revolution slider start -->
    <div class="tp-banner-container">
        <div class="tp-banner">

            <ul>
                <?php if(isset($HomeUnderMenuSlider)): ?>
                    <?php $__currentLoopData = $HomeUnderMenuSlider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li data-transition="fade" data-slotamount="7">
                            <?php if(isset($slide['image'])): ?><img alt="" data-lazyload="<?php echo e($slide['image']); ?>"
                                 data-bgposition="left center" data-kenburns="on" data-duration="14000"
                                 data-ease="Linear.easeNone" data-bgfit="100" data-bgfitend="130"
                                 data-bgpositionend="right center">
                        <?php endif; ?>
                            <div class="caption fade " data-autoplay="true" data-autoplayonlyfirsttime="true"
                                 data-nextslideatend="false" data-x="470" data-y="center" data-speed="500"
                                 data-start="10" data-easing="easeOutBahck">

                                <?php if(isset($slide['video'])): ?>
                                    <?php
                                        $url = $slide['video'];
                                        $url = str_replace('watch?v=','embed/',$url);
                                    ?>
                                    <iframe width="560" height="315" src="<?php echo e($url); ?>"
                                            frameborder="0"
                                            allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture"
                                            allowfullscreen></iframe>
                                <?php endif; ?>
                            </div>
                            <?php if(isset($slide['video'])): ?>
                                <?php if(isset($slide['h1'])): ?>

                                    <div class="caption slide-head tp-resizeme witTxt doItWhite"  style="width: 150px;word-wrap: break-word" data-x="0"
                                         data-y="center"
                                         data-speed="500" data-start="1700"
                                         data-easing="easeOutBack"><?php echo e($slide['h1']); ?>


                                    </div>
                                <?php endif; ?>
                                <?php if(isset($slide['h2'])): ?>
                                    <div class="caption slide-head tp-resizeme witTxt doItWhite" style="width: 150px;word-wrap: break-word" data-x="0"
                                         data-y="280" data-speed="700" data-start="1900"
                                         data-easing="easeOutBack"><?php echo e($slide['h2']); ?>

                                    </div>
                                <?php endif; ?>
                                <?php if(isset($slide['url'])): ?>
                                    <div class="caption larger-text tp-resizeme witTxt" data-x="0" data-y="300"
                                         data-speed="700" data-start="2300" data-easing="easeOutBack"><a
                                            href="<?php echo e($slide['url']); ?>"
                                            class="btn btn-md btn-skew themeColorBtn"><?php echo e(__('lang.details')); ?></a>
                                    </div>
                                <?php endif; ?>
                            <?php else: ?>
                                <?php if(isset($slide['h1'])): ?>
                                    <div class="caption slide-head tp-resizeme witTxt doLightBlack" data-x="center"
                                         data-y="150"
                                         data-speed="500" data-start="1700"
                                         data-easing="easeOutBack"><?php echo e($slide['h1']); ?>


                                    </div>
                                <?php endif; ?>
                                <?php if(isset($slide['h2'])): ?>
                                    <div class="caption large-title tp-resizeme witTxt doLightBlack" data-x="center"
                                         data-y="200" data-speed="700" data-start="1900"
                                         data-easing="easeOutBack"><?php echo e($slide['h2']); ?>

                                    </div>
                                <?php endif; ?>
                                <?php if(isset($slide['url'])): ?>
                                    <div class="caption larger-text tp-resizeme witTxt" data-x="center" data-y="300"
                                         data-speed="700" data-start="2300" data-easing="easeOutBack"><a
                                            href="<?php echo e($slide['url']); ?>"
                                            class="btn btn-md btn-skew themeColorBtn"><?php echo e(__('lang.details')); ?></a>
                                    </div>
                                <?php endif; ?>
                            <?php endif; ?>

                        </li>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>


            </ul>

        </div>
    </div>
    <!-- Revolution slider end -->

    <div class="sectionWrapper img-pattern">
        <div class="container">
            <div id="bannerArea">
                <div class="row fx" data-animate="fadeIn">
                    <div class="cell-3">
                        <div class='banner-card'>
                            <a href="/export-radar">
                                <img src='<?php echo e(asset('theme/images/banners/1.jpg')); ?>'/>
                                <div class='banner-pattern'></div>
                                <div class='shine'></div>
                                <div class="bounce_in_animation"><?php echo e(__('lang.nav_export_radar')); ?></div>
                            </a>
                        </div>
                    </div>

                    <div class="cell-3">
                        <div class='banner-card'>
                            <a href="/partner-list">
                                <img src="<?php echo e(asset('theme/images/banners/2.jpg')); ?>"/>
                                <div class='banner-pattern'></div>
                                <div class='shine'></div>
                                <div class="bounce_in_animation"><?php echo e(__('lang.partners')); ?></div>
                            </a>
                        </div>
                    </div>

                    <div class="cell-3">
                        <div class='banner-card'>
                            <a href="/doviz-radari">
                                <img src="<?php echo e(asset('theme/images/banners/3.jpg')); ?>"/>
                                <div class='banner-pattern'></div>
                                <div class='shine'></div>
                                <div class="bounce_in_animation"><?php echo e(__('lang.nav_foreign_money')); ?></div>
                            </a>
                        </div>
                    </div>

                    <div class="cell-3">
                        <div class='banner-card'>
                            <a href="/blog">
                                <img src='<?php echo e(asset('theme/images/banners/4.jpg')); ?>'/>
                                <div class='banner-pattern'></div>
                                <div class='shine'></div>
                                <div class="bounce_in_animation"><?php echo e(__('lang.news')); ?></div>
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <div class="clearfix"></div>

            <div class="cell-8">
                <div class="row">
                    <div class="block fx aboutTextArea margin-top-50" data-animate="fadeInLeft">
                        <h3 class="center block-head"><span class="main-color"><?php echo e(__('lang.welcome_message')); ?>

                        </h3>
                        <?php if(isset($about['homePageDesc'])): ?>
                        <p class="margin-bottom-20">
                            <?php echo e(strip_tags($about['homePageDesc'])); ?>


                        </p>
                        <?php endif; ?>
                        <a class="btn btn-md btn-skew themeColorBtn mb-15" href="/about-us">
                            <span><i class="fa fa-chevron-right selected"></i><?php echo e(__('lang.about_more')); ?></span>
                        </a>
                        <a class="btn btn-md btn-skew themeColorBtn mb-15" href="/panel/register">
                            <span><i class="fa fa-chevron-right selected"></i><?php echo e(__('lang.register_now')); ?></span>
                        </a> <br>
                        <?php if(isset($about['url'])): ?>
                        <a style="display: inline-block; margin-top: 15px;"
                           class="btn btn-md btn-3d btn-mulled_wine fx animated fadeInUp mb-15" href="<?php echo e($about['url']); ?>"
                           data-animate="fadeInUp" data-animation-delay="700" style="animation-delay: 700ms;">
                            <span><?php echo e(__('lang.download_catalog')); ?> <i class="fa fa-file-pdf-o"></i></span>
                        </a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="cell-4 fx" data-animate="bounceIn">
                <img alt="" src="<?php echo e(asset('theme/images/home/hakkimizda-sag.png')); ?>">
            </div>

        </div>
    </div>

    <section class="fastBooking" style="
				background: url(theme/images/appointmentformbg.jpg) center right no-repeat;
    			background-color: #ffffffb8;
				background-blend-mode: overlay;
				background-size: cover;">
        <form method="post" action="<?php echo e(route('contact.form')); ?>" id="myform">
            <?php echo csrf_field(); ?>
            <div class="container">
                <h3 class="center block-head">
						<span class="main-color">
							<?php echo e(__('lang.quick_apointment')); ?>

						</span>
                </h3>
                <div class="row">
                    <div class="cell-3">
                        <div class="form-input">
                            <label for="fastBookName"><?php echo e(__('lang.fullname')); ?><span class="red"> *</span></label>
                            <input type="text" id="fastBookName" name="name">
                        </div>
                    </div>
                    <div class="cell-3">
                        <div class="form-input">
                            <label for="fastBookEmail"><?php echo e(__('lang.email_adress')); ?><span class="red"> *</span></label>
                            <input type="email" id="fastBookEmail" name="email">
                        </div>
                    </div>
                    <div class="cell-3">
                        <div class="form-input">
                            <label><?php echo e(__('lang.requested_services')); ?><span class="red"> *</span></label>
                            <select name="service" id="fastBookService">

                                <?php $__currentLoopData = $findServiceswithoutId; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($key); ?>"><?php echo e($service->title); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </select>
                        </div>
                    </div>
                    <div class="cell-3">
                        <div class="form-input">
                            <label for="fastBookDate"><?php echo e(__('lang.requested_date')); ?><span class="red"> *</span></label>
                            <input type="date" name="date" id="fastBookDate">
                        </div>
                    </div>

                    <div class="cell-12" style="text-align: center;">
                        <a class="btn btn-md btn-skew themeColorBtn mb-15"
                           onclick="document.getElementById('myform').submit()">
                            <span><i class="fa fa-calendar selected"></i><?php echo e(__('lang.get_appointment')); ?></span>
                        </a>
                    </div>
                </div>
            </div>
        </form>
    </section>

    <!-- Services boxes style 1 start -->
    <div class="gry-bg">
        <div class="container">
            <div class="row">

                <?php $__currentLoopData = $findServiceswithoutId; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="cell-3 service-box-1 fx" data-animate="fadeInUp" data-animation-delay="200">
                        <div class="box-top">
                            <img src="<?php echo e($service->thumbnail); ?>">
                            <h3><?php echo e(($service->title)); ?></h3>
                            <p>
                            <?php
                                echo substr(strip_tags($service->content),0,250);
                            ?>
                            </p>
                            <a class="more-btn bold" href="<?php echo e(route('service.find',$service->slug)); ?>"><?php echo e(__('lang.services_details')); ?></a>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            </div>
        </div>
    </div>
    <!-- Services boxes style 1 start -->

    <!-- Portfolio start -->
    <div id="newsSection" class="sectionWrapper">
        <div class="container">
            <div class="row">
                <div class="cell-3">
                    <h3 class="block-head side-heading"><?php echo e(__('lang.latest')); ?> <span><?php echo e(__('lang.news')); ?></span>
                    </h3>
                    <p class="portfolio-lft-txt">
                        <?php echo e(__('lang.look_all_news_desc')); ?>

                    </p>
                    <div class="viewAll-home">
                        <a class="btn themeColorBtn mb-15" href="blog"><?php echo e(__('lang.look_all_news')); ?></a>
                    </div>
                </div>
                <div class="cell-9">
                    <div class="homeGallery portfolio">
                        <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div>
                                <div class="portfolio-item">
                                    <div class="img-holder">
                                        <div class="img-over">
                                            <a href="<?php echo e(route('post.find',$post->slug)); ?>" class="fx link"><b
                                                    class="fa fa-link"></b></a>
                                        </div>
                                        <img alt="" src="<?php echo e($post->thumbnail); ?>">
                                    </div>
                                    <div class="name-holder">
                                        <a href="<?php echo e(route('post.find',$post->slug)); ?>"
                                           class="project-name"><?php echo e($post->title); ?></a>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <?php endif; ?>

                    </div><!-- .portfolioGallery end -->
                </div>
            </div>
        </div>
    </div>
    <!-- Portfolio end -->

    <!-- Portfolio Staff -->
    <div class="sectionWrapper gry-bg">
        <div class="container">
            <h3 class="center block-head"><span class="main-color"><?php echo e(__('lang.partners')); ?></span>
            </h3>

            <div class="portfolioGallery portfolio">
                <?php if(isset($randomPartners)): ?>
                    <?php $__currentLoopData = $randomPartners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $partner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div>
                            <div class="portfolio-item">
                                <div class="img-holder">
                                    <div class="img-over">
                                        <a href="<?php echo e(route('partner.find',$partner->id)); ?>" class="fx link"><b
                                                class="fa fa-link"></b></a>
                                        <a href="<?php echo e($partner->avatar); ?>" class="fx zoom"
                                           data-gal="prettyPhoto[pp_gal"><b class="fa fa-search-plus"></b></a>
                                    </div>
                                    <img alt="" src="<?php echo e($partner->avatar); ?>">
                                </div>
                                <div class="name-holder">
                                    <a href="<?php echo e(route('partner.find',$partner->id)); ?>"
                                       class="project-name"><?php echo e($partner->name); ?></a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>

            <div class="clearfix"></div>

            <div class="view-all-projects"><a class="btn main-bg btn-3d btn-lg"
                                              href="/partner-list"><?php echo e(__('lang.all_partners')); ?></a></div>
        </div>
    </div>

    <!-- FUN Staff start -->
    <div class="fun-staff staff-1 block-bg-2 sectionWrapper">
        <div class="container">
            <!-- staff item start -->
            <div class="cell-2 fx" data-animate="fadeInDown" data-animation-delay="200">
                <div class="fun-number"><?php if(isset($fourBox['allusers'])): ?><?php echo e($fourBox['allusers']); ?>+ <?php endif; ?></div>
                <div class="fun-text main-bg"><?php echo e(__('lang.total_members')); ?></div>
                <div class="fun-icon"><i class="fa fa-leaf"></i></div>
            </div>
            <!-- staff item end -->

            <!-- staff item start -->
            <div class="cell-2 fx" data-animate="fadeInDown" data-animation-delay="400">
                <div class="fun-number"><?php if(isset($fourBox['allusers'])): ?><?php echo e($fourBox['providers']); ?>+ <?php endif; ?></div>
                <div class="fun-text main-bg"><?php echo e(__('lang.total_providers')); ?></div>
                <div class="fun-icon"><i class="fa fa-clock-o"></i></div>
            </div>
            <!-- staff item end -->

            <!-- staff item start -->
            <div class="cell-4 fx" data-animate="fadeInDown">
                <div class="fun-title bold"><span><?php echo e(__('lang.our_missions')); ?> </span></div>
            </div>
            <div class="cell-2 fx" data-animate="fadeInDown" data-animation-delay="600">
                <div class="fun-number"><?php if(isset($fourBox['allusers'])): ?><?php echo e($fourBox['employments']); ?>+ <?php endif; ?></div>
                <div class="fun-text main-bg"><?php echo e(__('lang.employments')); ?></div>
                <div class="fun-icon"><i class="fa fa-group"></i></div>
            </div>
            <!-- staff item end -->

            <!-- staff item start -->
            <div class="cell-2 fx" data-animate="fadeInDown" data-animation-delay="800">
                <div class="fun-number"><?php if(isset($fourBox['allusers'])): ?> <?php echo e($fourBox['exportvolume']); ?> + <?php endif; ?></div>
                <div class="fun-text main-bg"><?php echo e(__('lang.e_export_volume')); ?></div>
                <div class="fun-icon"><i class="fa fa-bell"></i></div>
            </div>
            <!-- staff item end -->

        </div><!-- .container end -->
    </div>
    <!-- FUN Staff end -->

    <div class="sectionWrapper img-pattern">
        <div class="container">
            <div class="row">
                <div class="cell-6 fx" data-animate="fadeInLeft">
                    <h3 class="block-head"><?php echo e(__('lang.faq')); ?></h3>
                    <ul id="accordion" class="accordion">


                        <?php if(isset($faqs)): ?>
                            <?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                    <h3 class="skew-25"><a href="#"><span class="skew25"><?php echo e($faq['question']); ?></span></a>
                                    </h3>
                                    <div class="accordion-panel active"><?php echo e($faq['answer']); ?>

                                    </div>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>


                    </ul>
                </div>
                <div class="cell-6 fx" data-animate="fadeInRight">
                    <h3 class="block-head"><?php echo e(__('contact.get_contact_us')); ?></h3>
                    <p>
                        <?php echo e(__('contact.if_you_have_a_any_question')); ?>

                    </p>
                    <div class="contact-form">
                        <form class="form-signin cform" method="post" action="<?php echo e(route('contact.form')); ?>" id="cform"
                              autocomplete="on">
                            <?php echo csrf_field(); ?>
                            <div class="form-input">
                                <label><?php echo e(__('contact.name')); ?><span class="red">*</span></label>
                                <input type="text" name="name" required>
                            </div>
                            <div class="form-input">
                                <label><?php echo e(__('contact.email')); ?><span class="red">*</span></label>
                                <input type="text" name="email" required>
                            </div>
                            <div class="form-input">
                                <label><?php echo e(__('contact.subject')); ?><span class="red">*</span></label>
                                <input type="text" name="subject" required>
                            </div>
                            <div class="form-input">
                                <label><?php echo e(__('contact.message')); ?><span class="red">*</span></label>
                                <textarea name="message" required></textarea>
                            </div>
                            <div>
                                <input type="submit" class="btn btn-large main-bg" value="<?php echo e(__('contact.send')); ?>">
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>
<!-- Content End -->

<?php /**PATH C:\Users\ylmzb\Desktop\e-ihracat\resources\views/pages/anasayfa.blade.php ENDPATH**/ ?>