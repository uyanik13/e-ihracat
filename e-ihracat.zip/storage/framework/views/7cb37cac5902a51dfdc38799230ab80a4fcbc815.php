﻿
		<!-- Content Start -->
		<div id="contentWrapper">
			<div class="page-title title-1">
				<div class="container">
					<div class="row">
						<div class="cell-12">
							<h1 class="fx" data-animate="fadeInLeft"><?php echo e(__('lang.nav_contact')); ?></h1>
							<div class="breadcrumbs main-bg fx" data-animate="fadeInUp">
								<span class="bold"><?php echo e(__('lang.you_are_here')); ?>:</span><a href="#"><?php echo e(__('lang.homepage')); ?></a><span
									class="line-separate">/</span><a href="#"><?php echo e(__('lang.nav_contact')); ?> </a>
							</div>
						</div>
					</div>
				</div>
			</div>

			<div class="padd-top-50">
				<div class="container">
					<div class="row">
						<div class="cell-7 contact-form fx" data-animate="fadeInLeft" id="contact">
							<h3 class="block-head"><?php echo e(__('contact.keep_contact_us')); ?></h3>
							<mark id="message"></mark>
							<form class="form-signin cform" method="post" action="<?php echo e(route('contact.form')); ?>" id="cform"
								autocomplete="on">
                                <?php echo csrf_field(); ?>
								<div class="form-input">
									<label><?php echo e(__('contact.name')); ?><span class="red">*</span></label>
									<input type="text" required="required" name="name" id="name">
								</div>
								<div class="form-input">
									<label><?php echo e(__('contact.email')); ?><span class="red">*</span></label>
									<input name="email" type="email" id="email" required="required">
								</div>
								<div class="form-input">
									<label><?php echo e(__('contact.phone')); ?></label>
									<input name="phone" type="text" id="phone">
								</div>
								<div class="form-input">
									<label><?php echo e(__('contact.message')); ?><span class="red">*</span></label>
									<textarea required="required" name="message" cols="40" rows="7" id="messageTxt"
										spellcheck="true"></textarea>
								</div>
								<div class="form-input">
									<input type="submit" class="btn btn-large main-bg" value="<?php echo e(__('contact.send')); ?>">&nbsp;&nbsp;<input
										type="reset" class="btn btn-large" value="<?php echo e(__('contact.reset')); ?>" id="reset">
								</div>
							</form>
						</div>
						<div class="cell-5 contact-detalis">
							<h3 class="block-head"><?php echo e(__('contact.contact_info_title')); ?></h3>
							<p class="fx" data-animate="fadeInRight">
                                <?php echo e(__('contact.contact_info_title_under_text')); ?>

							</p>
							<hr class="hr-style4">
							<div class="clearfix"></div>
							<div class="padding-vertical contactPageElements">
								<div class="cell-12 fx" data-animate="fadeInRight">
									<h4 class="main-color bold"><?php echo e(__('lang.center_place')); ?>: İstanbul</h4>
									<h5 class="bold"><?php echo e(__('contact.address')); ?></h5>
									<p><?php if(isset($setting['address'])): ?> <?php echo e($setting['address']->value); ?> <?php endif; ?></p>
									<h5 class="bold"><?php echo e(__('contact.email')); ?>:</h5>
									<p><a href="mailto:info@eihracatturkiye.com"><?php if(isset($setting['email'])): ?> <?php echo e($setting['email']->value); ?> <?php endif; ?></a></p>
									<h5 class="bold"><?php echo e(__('contact.phone')); ?>:</h5>
									<p><a href="tel:<?php if(isset($setting['phone'])): ?> <?php echo e($setting['phone']->value); ?> <?php endif; ?>"> <?php if(isset($setting['phone'])): ?> <?php echo e($setting['phone']->value); ?> <?php endif; ?></a></p>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>

			<div class="padd-vertical-45">
				<div class="container">
					<?php if(isset($setting['map_iframe'])): ?> <?php echo $setting['map_iframe']->value; ?> <?php endif; ?>
				</div>
			</div>
		</div>
<?php /**PATH C:\Users\ylmzb\Desktop\e-ihracat\resources\views/pages/contact.blade.php ENDPATH**/ ?>