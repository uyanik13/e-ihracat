<!--Footer Top Social start-->
<?php
    $recentPosts = Helper::recentPosts(3);
?>
<div class="footer-bar footer-bar-3">
    <div class="container">
        <div class="row">
            <div class="cell-10">
                <p><strong class="main-color"><?php echo e(__('lang.foot_eihracat')); ?></strong>- <a href="http://eihracatturkiye.com"
                                                                              class="main-bg"><span
                            data-view="Globalleşmeye">Dijitalleşmeye</span></a> hazır olun.
                </p>
            </div>
            <div class="cell-2 buyNow">
                <a class="btn btn-large main-bg" href="http://eihracatturkiye.com"><?php echo e(__('lang.foot_become_partner')); ?></a>
            </div>
        </div>
    </div>
</div>
<!--Footer Top Social end -->

<!-- Footer start -->
<footer id="footWrapper">
    <div class="footer-top">
        <div class="container">
            <div class="row">

                <!-- footer cell 1 start -->
                <div class="cell-3">
                    <div class="foot-logo"><img src="<?php echo e(asset('theme/images/logo-white.png')); ?>" alt=""></div>
                    <p><?php echo e(__('lang.foot_desc')); ?></p>
                    <ul class="social-list hover_links_effect">
                        <li><?php if(isset($setting['facebook']->value)): ?><a target="_blank" href="<?php echo e($setting['facebook']->value); ?>"><span
                                    class="fa fa-facebook"></span></a>
                            <?php endif; ?>
                        </li>
                        <li><?php if(isset($setting['instagram']->value)): ?><a target="_blank" href="<?php echo e($setting['instagram']->value); ?>"><span
                                    class="fa fa-instagram"></span></a>
                            <?php endif; ?>
                        </li>
                        <li><?php if(isset($setting['linkedin']->value)): ?><a target="_blank" href="<?php echo e($setting['linkedin']->value); ?>"><span
                                    class="fa fa-linkedin"></span></a>
                            <?php endif; ?>
                        </li>
                        <li>
                            <?php if(isset($setting['youtube']->value)): ?><a target="_blank"
                               href="<?php echo e($setting['youtube']->value); ?>"><span
                                    class="fa fa-youtube"></span></a> <?php endif; ?>
                        </li>
                    </ul>
                </div>
                <!-- footer cell 1 start -->


                <!-- main menu footer cell start -->
                <div class="cell-3">
                    <h3 class="block-head"><?php echo e(__('lang.foot_links')); ?></h3>
                    <ul class="footer-menu">
                        <li><a href="/index"><?php echo e(__('lang.nav_homepage')); ?></a></li>
                        <li><a href="our-services"><?php echo e(__('lang.nav_services')); ?></a></li>
                        <li><a href="partner-list"><?php echo e(__('lang.nav_partner')); ?></a></li>
                        <li><a href="appointment-form"><?php echo e(__('lang.nav_appointment')); ?></a></li>
                    </ul>
                </div>
                <!-- main menu footer cell start -->


                <!-- Recent  Post  footer cell start -->
                <div class="cell-3">
                    <h3 class="block-head"><?php echo e(__('lang.foot_last_posts')); ?> </h3>
                    <div class="recent-posts-footer">
                        <ul>
                            <?php $__empty_1 = true; $__currentLoopData = $recentPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <li>
                                    <div class="post-img">
                                        <a href="<?php echo e(route('post.find',$recent->slug)); ?>">
                                            <img src="<?php echo e($recent->thumnail); ?>" alt="">
                                        </a>
                                    </div>
                                    <div class="widget-post-info">
                                        <h4>
                                            <a href="<?php echo e(route('post.find',$recent->slug)); ?>">
                                                <?php echo e($recent->title); ?>

                                            </a>
                                        </h4>
                                        <div class="meta">
                                            <a href="<?php echo e(route('post.find',$recent->slug)); ?>">
                                                <span><i class="fa fa-clock-o"></i><?php echo e(Helper::getDateForHuman($recent->id)); ?></span>
                                            </a>
                                        </div>
                                    </div>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <?php endif; ?>
                        </ul>
                    </div>
                </div>
                <!-- Recent  Post footer cell start -->


                <!-- contact us footer cell start -->
                <div class="cell-3">
                    <h3 class="block-head"><?php echo e(__('lang.foot_contact_info')); ?></h3>
                    <ul>
                        <li class="footer-contact">
                            <?php if(isset($setting['address']->value)): ?>
                                <i class="fa fa-home"></i><span>
                                    <?php echo e($setting['address']->value); ?>

                                </span>
                             <?php endif; ?>
                        </li>
                        <li class="footer-contact">
                        <?php if(isset($setting['email']->value)): ?>
                            <i class="fa fa-globe"></i><span><a
                                    href="mailto:<?php echo e($setting['email']->value); ?>"><?php echo e($setting['email']->value); ?></a></span>
                        <?php endif; ?>
                        </li>
                        <li class="footer-contact">
                            <?php if(isset($setting['phone']->value)): ?>
                                <i class="fa fa-phone"></i><span><?php echo e($setting['phone']->value); ?></span>
                            <?php endif; ?>
                        </li>
                        <li class="footer-contact">
                            <i class="fa fa-map-marker"></i><span><a
                                    href="contact/#map_canvas"><?php echo e(__('lang.foot_go_map')); ?></a></span>
                        </li>
                        <li class="footer-contact newsletterArea">
									<span style="text-align: text-center">
										<h5><?php echo e(__('lang.foot_newsletter')); ?> </h5>
										<input class="newsletterInput" type="email" placeholder="E-Posta Adresiniz">
										<a style="display: block; margin-top: 15px; animation-delay: 700ms;"
                                           class="btn btn-md btn-3d main-bg fx animated fadeInUp mb-15" href="#"
                                           data-animate="fadeInUp" data-animation-delay="700">
											<span style="display: block; text-align: center;"><?php echo e(__('lang.foot_newsletter_submit')); ?></span>
										</a>
									</span>
                        </li>
                    </ul>
                </div>
                <!-- contact us footer cell end -->
            </div>
        </div>
    </div>

    <!-- footer bottom bar start -->
    <div class="footer-bottom">
        <div class="container">
            <div class="row">
                <!-- footer copyrights Center cell -->
                <div class="copyrights-center cell-12">
                    &copy; Copyright <b>E-İhracat Türkiye.</b> 2020. <?php echo e(__('lang.foot_all_rights')); ?>  <span><a
                            href="privacy.html"><?php echo e(__('lang.foot_privacy')); ?></a> | <a href="terms.html"><?php echo e(__('lang.foot_usage_policy')); ?></a></span>
                    <ul class="footer-menu-center">
                        <li>Development by <a href="index.html">Mindfactory</a></li>
                    </ul>
                </div>


            </div>
        </div>
    </div>
    <!-- footer bottom bar end -->

</footer>
<!-- Footer end -->

<!-- Back to top Link -->
<div id="to-top" class="main-bg"><span class="fa fa-chevron-up"></span></div>

<!-- WP Button -->
<div id="contactWp">
    <a target="_blank" href="https://wa.me/908503469956">
        <i class="fa fa-whatsapp"></i>
    </a>
</div>
</div>

<?php /**PATH C:\Users\ylmzb\Desktop\e-ihracat\resources\views/inc/footer.blade.php ENDPATH**/ ?>