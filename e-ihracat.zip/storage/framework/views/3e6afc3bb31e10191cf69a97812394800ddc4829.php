﻿

			<div id="exportRadar" style="background: url(<?php echo e(asset('theme/images/export-bg.jpg')); ?>) center center no-repeat; background-color: #d7d7d7d6; background-size: cover; background-blend-mode: overlay; top: -17px">
				<div class="container">
					<div class="row">
						<div class="radarMainMenu">
							<figure class="exportLogo">
								<img src="<?php echo e(asset('theme/images/logo.png')); ?>" alt="">
							</figure>
							<h1 style="text-align: center; font-weight: bold;">İhracat Bilgi Portalına Hoş Geldiniz!
							</h1>
							<div class="radarMenuContainer">
								<div class="rItem">
									<div class="radar-menu-item">
										<a href="benim-ulkem"><i class="fa fa-globe"></i>Hedef Ülkem</a>
									</div>
								</div>

								<div class="rItem">
									<div class="radar-menu-item">
										<a href="benim-urunum"><i class="fa fa-globe"></i>Benim Ürünüm</a>
									</div>
								</div>

								<div class="rItem">
									<div class="radar-menu-item">
										<a href="benim-temsilcim"><i class="fa fa-user"></i>Benim
											Temsilcim</a>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>

			</div>
		</div><?php /**PATH C:\Users\ylmzb\Desktop\e-ihracat\resources\views/pages/ihracat-radari.blade.php ENDPATH**/ ?>