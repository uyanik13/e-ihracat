
<?php
    $url = url("https://ticaret.gov.tr/destekler/ihracat-destekleri");
    $content = file_get_contents($url);



?>

<div id="contentWrapper">
    <div class="page-title title-1">
        <div class="container">
            <div class="row">
                <div class="cell-12">
                    <h1 class="fx" data-animate="fadeInLeft"><?php echo e($page->title); ?></h1>

                </div>
            </div>
        </div>
    </div>

	<div class="page-content ">

        <div class="padd-top-50">
            <div class="container">
				<div class="col-lg-3 col-md-4 mb-xs-35">
					<!--=======  contact page side content  =======-->
                    <?php echo html_entity_decode($content); ?>

					<!--=======  End of contact form content =======-->
				</div>
			</div>
		</div>
	</div>

	<!--=====  End of Contact page content  ======-->


	<!--=============================================
	=            Footer         =
	=============================================-->



	<!--=====  End of Footer  ======-->


	<!-- scroll to top  -->
	<a href="#" class="scroll-top"></a>
	<!-- end of scroll to top -->



<?php /**PATH C:\Users\ylmzb\Desktop\e-ihracat\resources\views/pages/devlet-tesvikleri.blade.php ENDPATH**/ ?>