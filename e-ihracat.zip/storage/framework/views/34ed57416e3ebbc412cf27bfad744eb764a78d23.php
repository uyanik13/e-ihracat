<li class="widget search-w fx" data-animate="fadeInLeft">
    <h3 class="widget-head"><?php echo e(__('lang.partner_search')); ?></h3>
    <div class="widget-content">
        <form action="#" method="get">
            <input type="text" onkeyup="live_user_search()"  id="search_input_user" class="txt-box"
                   placeholder="Anahtar Kelime Girin..." />
        </form>
    </div>
    <div id="search_result_user" class="bg-info">

    </div>
</li>
<?php /**PATH C:\Users\ylmzb\Desktop\e-ihracat\resources\views/pages/partials/partner_search.blade.php ENDPATH**/ ?>