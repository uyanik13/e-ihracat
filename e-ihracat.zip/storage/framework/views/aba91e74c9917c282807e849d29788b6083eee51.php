﻿		<!-- Content Start -->
		<div id="contentWrapper" style="background: url(<?php echo e(asset('theme/images/doviz-bg.jpg')); ?>) center center no-repeat; background-color: #d7d7d7d6; background-size: cover; background-blend-mode: overlay;">
			<div style="display: flex; justify-content: center; align-items: center; padding: 60px 0">
				<div id="W3179"></div>
			</div>
			
		</div>


<?php /**PATH C:\Users\ylmzb\Desktop\e-ihracat\resources\views/pages/doviz-radari.blade.php ENDPATH**/ ?>