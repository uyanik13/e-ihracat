﻿



		<!-- Content Start -->
		<div id="contentWrapper" style="top: 0">

            <div id="exportCountry" style="background: url(<?php echo e(asset('theme/images/export-bg.jpg')); ?>) center center no-repeat; background-color: #d7d7d7d6; background-size: cover; background-blend-mode: overlay;">


                <bilgi-bankasi-layout></bilgi-bankasi-layout>


			</div>
		</div>
<?php if($category === 'benim-urunum'): ?>
    <script type="text/javascript" src="<?php echo e(asset('theme/js/app.js')); ?>"></script>
<?php endif; ?>
<?php /**PATH C:\Users\ylmzb\Desktop\e-ihracat\resources\views/pages/benim-urunum.blade.php ENDPATH**/ ?>