﻿<?php
    $faqs = Helper::findCustomData('Faq');
$popularPosts =Helper::recentPosts(3);
?>
		<!-- Content Start -->
		<div id="contentWrapper">
			<div class="page-title title-1">
				<div class="container">
					<div class="row">
						<div class="cell-12">
							<h1 class="fx" data-animate="fadeInLeft">Sıkça Sorulan <span>Sorular</span></h1>
							<div class="breadcrumbs main-bg fx" data-animate="fadeInUp">
								<span class="bold">Buradasınız:</span><a href="#">Anasayfa</a><span
									class="line-separate">/</span><a href="#">S.S.S</a>
							</div>
						</div>
					</div>
				</div>
			</div>

			<div class="sectionWrapper">
				<div class="container">
					<div class="row">
						<div class="cell-9">
							<h3 class="block-head">Sıkça Sorulan Sorular</h3>
							<p class="hint"><?php echo e(__('sss.title')); ?></p>
							<p><?php echo e(__('sss.description')); ?>

							</p>

							<ul id="accordion" class="accordion">
                               <?php if(isset($faqs)): ?> <?php $__empty_1 = true; $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
								<li>
									<h3 class="skew-25"><a href="#"><span class="skew25"><?php echo e($faq['question']); ?></span></a></h3>
									<div class="accordion-panel active"><?php echo e($faq['answer']); ?>

									</div>
								</li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <?php endif; ?>
                                   <?php endif; ?>
							</ul>
						</div>
						<aside class="cell-3 right-sidebar">
							<ul class="sidebar_widgets">
								<li class="widget search-w fx" data-animate="fadeInRight">
									<h3 class="widget-head">Arama</h3>
									<div class="widget-content">
										<form action="#" method="get">
											<input type="text" name="t" id="t2-search" class="txt-box"
												placeholder="Anahtar Kelime Girin..." />
											<button type="submit" class="btn"><i class="fa fa-search"></i></button>
										</form>
									</div>
								</li>

								<li class="widget r-posts-w fx" data-animate="fadeInRight">
									<h3 class="widget-head">Popüler Gönderiler</h3>
									<div class="widget-content">
										<ul>
                                            <?php $__empty_1 = true; $__currentLoopData = $popularPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                <?php ($dateFull = Helper::getDateForHuman($post->created_at)); ?>
											<li>
												<div class="post-img">
                                                    <a href="<?php echo e(route('post.find',$post->slug)); ?>">
													<img src="<?php echo e($post->thumbnail); ?>" alt=""></a>
												</div>
												<div class="widget-post-info">
													<h4>
														<a href="<?php echo e(route('post.find',$post->slug)); ?>">
															<?php echo e($post->title); ?>

														</a>
													</h4>
													<div class="meta">
														<span><i class="fa fa-clock-o"></i><?php echo e($dateFull); ?></span>
													</div>
												</div>
											</li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                <?php endif; ?>
										</ul>
									</div>
								</li>

								<?php echo $__env->make('pages.partials.contact_info', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
							</ul>
						</aside>
					</div>
				</div>
			</div>

		</div>
		<!-- Content End -->
<?php /**PATH C:\Users\ylmzb\Desktop\e-ihracat\resources\views/pages/faq.blade.php ENDPATH**/ ?>