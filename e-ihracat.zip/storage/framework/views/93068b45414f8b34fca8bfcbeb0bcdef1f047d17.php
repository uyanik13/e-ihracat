<?php
    $recentPosts = Helper::recentPosts(3)
?>

<aside class="cell-3 right-sidebar">
    <ul class="sidebar_widgets">
        <li class="widget search-w fx" data-animate="fadeInRight">
            <h3 class="widget-head"><?php echo e(__('lang.blog_search')); ?></h3>
            <div class="widget-content">
                <form action="#" method="get">
                    <input type="text" name="t" onkeyup="live_post_search()" id="search_input_post"
                           class="txt-box"
                           placeholder="Anahtar Kelime Girin..."/>
                    <button type="submit" class="btn"><i class="fa fa-search"></i></button>
                </form>

            </div>
            <div id="search_result_post" class="bg-info">

            </div>
        </li>

        <li class="widget r-posts-w fx" data-animate="fadeInRight">
            <h3 class="widget-head"><?php echo e(__('lang.blog_new_posts')); ?></h3>
            <div class="widget-content">
                <ul>
                    <?php if(isset($recentPosts)): ?>
                        <?php $__empty_1 = true; $__currentLoopData = $recentPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recentPost): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <?php
                                $recentDate = Helper::getDateForHuman($recentPost->created_at);
                            ?>
                            <li>
                                <div class="post-img">
                                    <img src="<?php echo e($recentPost->thumbnail); ?>" alt="">
                                </div>
                                <div class="widget-post-info">
                                    <h4>
                                        <a href="<?php echo e(route('post.find',$recentPost->slug)); ?>">
                                            <?php echo e($recentPost->title); ?>

                                        </a>
                                    </h4>
                                    <div class="meta">
                                        <span><i class="fa fa-clock-o"></i><?php echo e($recentDate); ?></span>
                                    </div>
                                </div>
                            </li>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <?php endif; ?>
                    <?php endif; ?>
                </ul>
            </div>
        </li>

        <?php echo $__env->make('pages.partials.contact_info', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </ul>
</aside>
<?php /**PATH C:\Users\ylmzb\Desktop\e-ihracat\resources\views/pages/partials/blog-sidebar.blade.php ENDPATH**/ ?>