<li class="widget blog-cat-w fx" data-animate="fadeInLeft">
    <h3 class="widget-head"><?php echo e(__('lang.can_contact_withus')); ?></h3>
    <div class="widget-content">
        <ul class="sidebarCallLocation">
            <li><a title="Whatsapp Destek Hattı" href="https://wa.me/<?php if(isset($setting['phone'])): ?><?php echo e($setting['phone']->value); ?> <?php endif; ?>"><i
                        class="fa fa-whatsapp fa-2x"></i></a></li>
            <li><a title="Telefonla Ulaşın" href="tel:<?php if(isset($setting['phone'])): ?> <?php echo e($setting['phone']->value); ?> <?php endif; ?>"><i
                        class="fa fa-phone fa-2x"></i></a>
            <li><a title="E-Posta İletişim" href="mailto:<?php echo e($setting['email']->value); ?>"><i
                        class="fa fa-envelope fa-2x"></i></a>
            </li>
        </ul>
    </div>
</li>
<?php /**PATH C:\Users\ylmzb\Desktop\e-ihracat\resources\views/pages/partials/contact_info.blade.php ENDPATH**/ ?>