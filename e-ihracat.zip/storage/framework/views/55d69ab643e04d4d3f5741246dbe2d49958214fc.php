﻿<?php
    $findServiceswithoutId5 = Helper::findServiceswithoutId();
    $QuickServiceList = Helper::findCustomData('QuickServiceList');
?>


<!-- Content Start -->
<div id="contentWrapper">
    <div class="page-title title-1">
        <div class="container">
            <div class="row">
                <div class="cell-12">
                    <h1 class="fx" data-animate="fadeInLeft"><?php echo e($page->title); ?>

                    </h1>
                    <div class="breadcrumbs main-bg fx" data-animate="fadeInUp">
                        <span class="bold"><?php echo e(__('lang.you_are_here')); ?>:</span><a
                            href="#"><?php echo e(__('lang.homepage')); ?></a><span
                            class="line-separate">/</span><a href="#"><?php echo e(__('lang.our_services')); ?> </a><span
                            class="line-separate">/</span><span><?php echo e($page->title); ?></span>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="sectionWrapper">
        <div class="container">
            <div class="row">
                <div class="cell-9 servicesDetails">

                    <h1 class="block-head  margin-bottom-40 fx style6 animated fadeInUp"
                        data-animate="fadeInUp">
                        <span><?php echo e($page->title); ?></span>
                    </h1>
                    <?php echo html_entity_decode($page->content); ?>

                </div>
                <aside class="cell-3 right-sidebar" id="servicesAccordion">
                    <ul class="sidebar_widgets">

                        <li class="widget r-posts-w fx" data-animate="fadeInLeft">
                            <h3 class="widget-head"><?php echo e(__('lang.our_services')); ?></h3>
                            <div class="widget-content">
                                <ul>
                                    <li>
                                        <ul id="accordion2" class="accordion">
                                            <?php $__empty_1 = true; $__currentLoopData = $findServiceswithoutId5; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                <?php
                                                        $relevantServices = Helper::childServices($service->id);
                                                ?>
                                                <li>
                                                    <h3><a href="partner-details.html"><span class="bold"
                                                                                             class="skew25"><?php echo e(substr($service->title,0,25)); ?></span></a>
                                                    </h3>
                                                    <?php if(isset($relevantServices)): ?>
                                                        <?php
                                                            $relevantServices =$relevantServices;
                                                        ?>
                                                        <div class="accordion-panel <?php echo e($key == 0 ? 'active' : ''); ?>">
                                                            <?php if(isset($relevantServices)): ?>
                                                                <?php $__currentLoopData = $relevantServices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $relevantService): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <a href="<?php echo e(route('service.find',$relevantService->slug)); ?>"><?php echo e($relevantService['title']); ?></a>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            <?php endif; ?>
                                                        </div>
                                                    <?php endif; ?>
                                                </li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <?php endif; ?>
                                        </ul>
                                    </li>
                                </ul>
                            </div>
                        </li>


                        <?php echo $__env->make('pages.partials.contact_info', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <li class="widget r-posts-w fx" data-animate="fadeInRight">
                            <h3 class="widget-head"><?php echo e(__('lang.service_request_form')); ?></h3>
                            <div class="widget-content">
                                <div class="cell-12 contact-form fx" data-animate="fadeInLeft" id="contact">
                                    <mark id="message"></mark>
                                    <form class="form-signin cform" method="post" action="<?php echo e(route('contact.form')); ?>"
                                          id="cform"
                                          autocomplete="on">
                                        <?php echo csrf_field(); ?>
                                        <div class="form-input">
                                            <label><?php echo e(__('lang.fullname')); ?><span class="red">*</span></label>
                                            <input type="text" required="required" name="name"
                                                   id="servicesName">
                                        </div>
                                        <div class="form-input">
                                            <label><?php echo e(__('lang.email_adress')); ?><span class="red">*</span></label>
                                            <input name="email" type="email" id="servicesEmail"
                                                   required="required">
                                        </div>
                                        <div class="form-input">
                                            <label><?php echo e(__('lang.phone_number')); ?></label>
                                            <input name="phone" type="text" id="servicesPhone">
                                        </div>
                                        <div class="form-input">
                                            <label><?php echo e(__('lang.choosen_services')); ?></label>
                                            <select name="servicesSelectArea" id="servicesSelectArea">
                                                <?php if(isset($QuickServiceList)): ?> <?php $__currentLoopData = $QuickServiceList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($key); ?>"><?php echo e($item['key']); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <?php endif; ?>
                                            </select>
                                        </div>
                                        <div class="form-input">
                                            <label><?php echo e(__('lang.message')); ?><span class="red">*</span></label>
                                            <textarea required="required" name="message" cols="40" rows="7"
                                                      id="servicesMessageTxt" spellcheck="true"></textarea>
                                        </div>
                                        <div class="form-input" style="text-align: center;">
                                            <input type="submit" class="btn btn-large main-bg" value="Gönder">
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </li>
                    </ul>
                </aside>
            </div>
        </div>
    </div>

</div>
<!-- Content End -->
<?php /**PATH C:\Users\ylmzb\Desktop\e-ihracat\resources\views/components/detail_components/service.blade.php ENDPATH**/ ?>