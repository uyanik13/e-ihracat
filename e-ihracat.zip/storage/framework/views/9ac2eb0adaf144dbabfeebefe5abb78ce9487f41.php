<link rel="shortcut icon" href="<?php echo e(asset('theme/images/favicon.ico')); ?>">
<!-- CSS StyleSheets -->
<link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300;400;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet"
      href="http://fonts.googleapis.com/css?family=Open+Sans:400,300,700,800&amp;amp;subset=latin,latin-ext">
<link rel="stylesheet" href="<?php echo e(asset('theme/css/font-awesome.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('theme/css/animate.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('theme/css/prettyPhoto.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('theme/css/slick.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('theme/rs-plugin/css/settings.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('theme/css/style.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('theme/css/custom.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('theme/css/responsive.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('theme/css/skins/defaultskin.css')); ?>">
<?php /**PATH C:\Users\ylmzb\Desktop\e-ihracat\resources\views/inc/head-scripts.blade.php ENDPATH**/ ?>