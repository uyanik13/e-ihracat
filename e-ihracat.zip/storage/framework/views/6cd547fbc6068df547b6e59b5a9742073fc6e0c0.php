﻿

		<!-- Content Start -->
		<div id="contentWrapper">

            <div id="exportCountry" style="background: url(<?php echo e(asset('theme/images/export-bg.jpg')); ?>) center center no-repeat; background-color: #d7d7d7d6; background-blend-mode: overlay;">


                <bilgi-bankasi-layout></bilgi-bankasi-layout>


			</div>
		</div>
<?php /**PATH C:\Users\ylmzb\Desktop\e-ihracat\resources\views/pages/ihracat-ulke-detayi.blade.php ENDPATH**/ ?>