

	<div class="page-content ">

		<div class="container">
					<!--=======  contact page side content  =======-->
                    <div class="faq-area page-content mb-50 mt-50">
                        <div class="container">
                          <div class="row">
                            <div class="col-lg-12">
                              <div class="faq-wrapper">

                                <div class="text-center">
                                  <h1>404</h1>
                                  <h2>Page Not Found</h2>
                                  <p>Sorry, but the page you are looking for is not found. Please, make sure you have typed
                                    the current URL</p>
                                </div>

                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
					<!--=======  End of contact form content =======-->

		</div>
	</div>

	<!--=====  End of Contact page content  ======-->


	<!--=============================================
	=            Footer         =
	=============================================-->



	<!--=====  End of Footer  ======-->


	<!-- scroll to top  -->
	<a href="#" class="scroll-top"></a>
	<!-- end of scroll to top -->



<?php /**PATH C:\Users\ylmzb\Desktop\e-ihracat\resources\views/pages/404.blade.php ENDPATH**/ ?>