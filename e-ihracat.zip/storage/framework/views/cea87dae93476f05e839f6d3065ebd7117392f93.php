﻿<?php
    $dateArray = Helper::getDateForHuman($post->created_at,1);
    $recentPosts = Helper::recentPosts(3);
    $comments = Helper::getComments($post->id,false);
      $canVote = Helper::canVotePost($post->id);

      $tags = Helper::jsonToArray($post->options);

?>


<!-- Content Start -->
<div id="contentWrapper">
    <div class="page-title title-1">
        <div class="container">
            <div class="row">
                <div class="cell-12">
                    <h1 class="fx" data-animate="fadeInLeft"><?php echo e(__('lang.blog_details')); ?></h1>
                    <div class="breadcrumbs main-bg fx" data-animate="fadeInUp">
                        <span class="bold"><?php echo e(__('lang.you_are_here')); ?>:</span><a href="#"><?php echo e(__('lang.homepage')); ?></a><span
                            class="line-separate">/</span><a href="#"><?php echo e(__('lang.nav_blog')); ?></a><span
                            class="line-separate">/</span><span><?php echo e(__('lang.blog_details')); ?></span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="sectionWrapper">
        <div class="container">
            <div class="row">
                <div class="cell-9">
                    <div class="blog-posts">
                        <div class="post-item fx" data-animate="fadeInLeft">
                            <div class="details-img">
                                <div class="post-lft-info">
                                    <div class="main-bg"><?php echo e($dateArray[0]); ?><br><?php echo e($dateArray[1]); ?><br><?php echo e($dateArray[2]); ?>

                                        <span class="tri-col"></span>
                                    </div>
                                </div>
                                
                            </div>
                            <article class="post-content">
                                <div class="post-info-container" style="margin-top: 130px">
                                    <h1 class="main-color"><?php echo $post->title; ?>

                                    </h1>
                                </div>
                                <?php echo $post->content; ?>


                                <div class="post-tags">
                                    <i class="fa fa-tags"></i><span><?php echo e(__('lang.blog_tags')); ?>: </span>
                                    <?php if(isset($tags)): ?>
                                        <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key1 => $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if(isset($tag)): ?>
                                            <?php $__currentLoopData = $tag; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key2 => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <a><?php echo e($item); ?></a>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>


                                    <div class="share-post">
                                        <span class="sh"><?php echo e(__('lang.blog_details_share')); ?>:</span>
                                        <div id="shareme" data-text="Share this post"></div>
                                    </div>
                            </article>
                        </div>
                        <div class="comments">
                            <h3 class="block-head"><?php echo e(__('lang.blog_comments')); ?></h3>
                            <ul class="comment-list">
                                <li>
                                    <?php if(isset($comments)): ?>
                                        <?php $__empty_1 = true; $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <?php
                                                $childComment = Helper::getChildComments($comment->id);
                                            ?>
                                            <article class="comment">
                                                <img src="<?php echo e($comment->user->avatar); ?>" alt="avatar"
                                                     class="comment-avatar">
                                                <div class="comment-content">
                                                    <h5 class="comment-author skew-25">
                                                        <span class="author-name skew25"><?php echo e($comment->user->name); ?></span>
                                                        <a href="#commentForm"
                                                           onclick="setToWhomComment(<?php echo e($comment->id); ?>)"
                                                           class="comment-reply main-bg"><span
                                                                class="skew25"><i
                                                                    class="fa fa-comment"></i><?php echo e(__('lang.blog_comment_answer')); ?></span></a>
                                                        <span
                                                            class="comment-date skew25"><?php echo e(Helper::getDateForHuman($comment->created_at)); ?></span>
                                                    </h5>
                                                    <p>
                                                        <?php echo e($comment->content); ?>

                                                    </p>
                                                </div>
                                            </article><!-- End .comment -->
                                            <?php if(isset($childComment)): ?>
                                                <?php $__empty_2 = true; $__currentLoopData = $childComment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                                    <ul class="child-comment">
                                                        <li>
                                                            <article class="comment">
                                                                <img src="<?php echo e($child->user->avatar); ?>"
                                                                     alt="avatar"
                                                                     class="comment-avatar">
                                                                <div class="comment-content">
                                                                    <h5 class="comment-author skew-25">
                                                                        <span
                                                                            class="author-name skew25"><?php echo e($child->user->name); ?></span>
                                                                        <a href="#commentForm"
                                                                           onclick="setToWhomComment(<?php echo e($comment->id); ?>)"
                                                                           class="comment-reply main-bg"><span
                                                                                class="skew25"><i
                                                                                    class="fa fa-comment"></i><?php echo e(__('lang.blog_comment_answer')); ?></span></a>
                                                                        <span
                                                                            class="comment-date skew25"><?php echo e(Helper::getDateForHuman($child->created_at)); ?></span>
                                                                    </h5>
                                                                    <p><?php echo e($child->content); ?></p>
                                                                </div>
                                                            </article><!-- End .comment -->
                                                        </li>
                                                    </ul><!-- End .child-comment -->
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <?php endif; ?>
                                <?php endif; ?>
                            </ul><!-- End .comment-list -->
                        </div>
                        <?php if(auth()->guard()->guest()): ?>
                        <?php echo e(__('lang.comment_login')); ?>

                            <a href="/panel/login" class="btn btn-danger"> <?php echo e(__('lang.please_login')); ?></a>
                        <?php endif; ?>
                        <?php if(auth()->guard()->check()): ?>
                            <form action="<?php echo e(route('add_comment_to_post',$post->id)); ?>" method="post"
                                  class="leave-comment contact-form" id="commentForm">
                                <?php echo csrf_field(); ?>
                                <h3 class="block-head"><?php echo e(__('lang.do_comment')); ?></h3>
                                <p><?php echo e(__('lang.comment_description')); ?></p>
                                <div class="row">

                                    
                                    <?php if($canVote): ?>
                                        <div class="cell-12">
                                            <div class="form-input rating">
                                                <span class="bold"><?php echo e(__('lang.your_rating')); ?>: </span>
                                                <span>1<input value="1" class="divideThis" type="radio"
                                                              name="point"></span>
                                                <span>2<input value="2" class="divideThis" type="radio"
                                                              name="point"></span>
                                                <span>3<input value="3" class="divideThis" type="radio"
                                                              name="point"></span>
                                                <span>4<input value="4" class="divideThis" type="radio"
                                                              name="point"></span>
                                                <span>5<input value="5" class="divideThis" type="radio"
                                                              name="point"></span>

                                            </div>
                                        </div>
                                    <?php endif; ?>
                                    <div class="cell-12">
                                        <div class="form-input">
											<textarea class="txt-box textArea" name="content" cols="40" rows="7"
                                                      id="messageTxt" placeholder="Yorumunuz" spellcheck="true"
                                                      required></textarea>
                                            <input type="hidden" name="isFromPartnerPage" value="0">
                                            <input type="hidden" name="reply_to" id="formCommentHidden">
                                        </div>
                                    </div>
                                    <div class="cell-12">
                                        <input type="submit" class="btn btn-large main-bg" value="Yorum Yap">
                                    </div>
                                </div>
                            </form>
                        <?php endif; ?>
                    </div>
                </div>

                <?php echo $__env->make('pages.partials.blog-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
    </div>

</div>
<!-- Content End -->
<?php /**PATH C:\Users\ylmzb\Desktop\e-ihracat\resources\views/components/detail_components/blog-single.blade.php ENDPATH**/ ?>