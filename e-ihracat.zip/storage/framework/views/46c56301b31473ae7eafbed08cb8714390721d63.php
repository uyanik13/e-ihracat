﻿<?php
    $allPosts = Helper:: all_posts();
    $recentPosts = Helper::recentPosts(3);
?>

<!-- Content Start -->
		<div id="contentWrapper">
			<div class="page-title title-1">
				<div class="container">
					<div class="row">
						<div class="cell-12">
							<h1 class="fx" data-animate="fadeInLeft"><?php echo e(__('lang.blog_news')); ?> </h1>
							<div class="breadcrumbs main-bg fx" data-animate="fadeInUp">
								<span class="bold"><?php echo e(__('lang.you_are_here')); ?>:</span><a href="#"><?php echo e(__('lang.homepage')); ?></a><span
									class="line-separate">/</span><a href="#"><?php echo e(__('lang.nav_blog')); ?></a>
							</div>
						</div>
					</div>
				</div>
			</div>

			<div class="sectionWrapper">
				<div class="container">
					<div class="row">
						<div class="cell-9 masonry">
							<div class="blog-posts">
                            <?php $__empty_1 = true; $__currentLoopData = $allPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
								<div class="post-item" style="margin-bottom: 45px" >
									<div class="post-image">
										<a href="<?php echo e(route('post.find',$post->slug)); ?>">
											<div class="mask"></div>
											<div class="post-lft-info">

                                            <div class="main-bg"><?php echo e($post->created_at->diffForHumans()); ?></div>
											</div>
											<img src="<?php echo e($post->thumbnail); ?>" alt="Blog Görseli">
										</a>
									</div>
									<article class="post-content">
										<div class="post-info-container">
											<div class="post-info">
												<h2><a class="main-color" href="<?php echo e(route('post.find',$post->slug)); ?>"><?php echo e($post->title); ?></a></h2>
											</div>
										</div>
											<?php echo substr($post->content,0,250); ?>

									</article>
									<a class="btn btn-md btn-3d main-bg fx animated fadeInUp readMoreBtn" href="<?php echo e(route('post.find',$post->slug)); ?>"
										data-animate="fadeInUp" data-animation-delay="100"
										style="animation-delay: 100ms;">
										<span><i class="fa fa-search-plus selectedI"></i><?php echo e(__('lang.read_more')); ?></span>
									</a>
								</div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <?php endif; ?>
							</div>
						</div>
                         <?php echo $__env->make('pages.partials.blog-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
					</div>
				</div>
			</div>

		</div>
		<!-- Content End -->


<?php /**PATH C:\Users\ylmzb\Desktop\e-ihracat\resources\views/pages/blog.blade.php ENDPATH**/ ?>