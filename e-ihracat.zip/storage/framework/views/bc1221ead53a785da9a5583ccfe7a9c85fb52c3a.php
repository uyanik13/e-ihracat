<?php if($page): ?>
<?php switch($page->slug):
    case ($page->slug): ?>
        <?php if(\View::exists('pages/'.$page->slug)): ?>
        <?php echo $__env->make('pages/'.$page->slug, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php else: ?>
        <?php echo $__env->make('pages/default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
    <?php break; ?>
    <?php default: ?>
     <?php echo $__env->make('pages/default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endswitch; ?>
<?php else: ?>
<?php echo $__env->make('pages/404', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>

<?php /**PATH C:\Users\ylmzb\Desktop\e-ihracat\resources\views/components/page.blade.php ENDPATH**/ ?>