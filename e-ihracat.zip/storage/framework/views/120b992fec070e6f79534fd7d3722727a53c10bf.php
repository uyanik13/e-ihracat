﻿<?php
    $AboutUSMembers = Helper::findCustomData('AboutUSMembers');
    $fourBox = Helper::findCustomData('fourBox');
    $aboutUsPage = Helper::findCustomData('aboutUsPage');
?>

<!-- Content Start -->
<div id="contentWrapper">
    <div class="page-title title-1">
        <div class="container">
            <div class="row">
                <div class="cell-12">
                <h1 class="fx" data-animate="fadeInLeft"><?php echo e(__('lang.about_us')); ?></span></h1>
                    <div class="breadcrumbs main-bg fx" data-animate="fadeInUp">
                    <span class="bold"><?php echo e(__('lang.you_are_here')); ?>:</span><a href=/"><?php echo e(__('lang.homepage')); ?></a><span
                            class="line-separate">/</span><a href="#"><?php echo e(__('lang.about_us')); ?> </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="sectionWrapper">
        <div class="container">
            <div class="fx" data-animate="fadeInUp">
                <h3 class="block-head"><?php echo e(__('lang.export_future')); ?></h3>
                <div class="cell-6">
                    <?php if(isset($aboutUsPage['content'])): ?>  
                    <?php echo $aboutUsPage['content']; ?>

                    <div class="aboutBtnArea">
                        <a class="btn btn-md btn-skew btn-3d main-bg" href="our-services">
                        <span><i class="fa fa-gift selectedI"></i><?php echo e(__('lang.our_services')); ?></span>
                        </a>
                        <a class="btn btn-md btn-skew btn-3d main-bg" href="/panel/register">
                            <span><i class="fa fa-user-secret selectedI"></i><?php echo e(__('lang.become_a_partner')); ?></span>
                        </a>
                    </div>
                    <?php endif; ?>
                </div>
                <div class="cell-6">
                    <figure>
                        <img src="<?php echo e(asset('theme/images/about.png')); ?>" alt="">
                    </figure>
                </div>
            </div>

            <div class="clearfix"></div>

            <div class="padd-top-50">
                <div class="cell-6 fx" data-animate="fadeInLeft" style="padding-right: 10px;">
                    <div class="row">
                        <div>
                        <h3 class="block-head"><?php echo e(__('lang.our_mission')); ?></h3>
                        <?php if(isset($aboutUsPage['mission'])): ?>
                            
                        
                            <?php echo $aboutUsPage['mission']; ?>

                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="cell-1"></div>
                <div class="cell-5 fx" data-animate="fadeInRight" style="padding-left: 10px;">
                    <div class="row">
                        <div>
                            <?php if(isset($aboutUsPage['vision'])): ?>
                            <h3 class="block-head"><?php echo e(__('lang.our_vision')); ?></h3>
                            <?php echo $aboutUsPage['vision']; ?>

                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="sectionWrapper gry-pattern">
        <div class="container team-boxes">
            <h3 class="block-head"><?php echo e(__('lang.our_team_title')); ?></h3>
            <p>
               <?php echo e(__('lang.our_team_desc')); ?>

            </p>
            <?php if(isset($AboutUSMembers)): ?>
                <?php $__empty_1 = true; $__currentLoopData = $AboutUSMembers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                    <div class="cell-4 fx" data-animate="bounceIn" data-animation-delay="<?php echo e(200*$key); ?>">
                        <div class="team-box">
                            <div class="team-img">
                                <?php if(isset($member['image'])): ?>
                                    <img alt="" src="<?php echo e($member['image']); ?>">
                                <?php endif; ?>
                                <?php if(isset($member['name'])): ?>
                                    <h3><?php echo e($member['name']); ?></h3>
                                <?php endif; ?>
                            </div>
                            <div class="team-details">
                                <?php if(isset($member['name'])): ?>
                                    <h3><?php echo e($member['name']); ?></h3>
                                <?php endif; ?>
                                <?php if(isset($member['position'])): ?>
                                    <div class="t-position"><?php echo e($member['position']); ?></div>
                                <?php endif; ?>
                                <div class="team-socials">
                                    <ul>
                                        <li>
                                            <?php if(isset($member['url'])): ?>
                                                <a class="teamLinkedin" href="<?php echo e($member['url']); ?>" title="linkedin">
                                                    <span class="fa fa-linkedin"></span>
                                                </a>
                                            <?php endif; ?>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <?php endif; ?>
                <?php endif; ?>
        </div>
    </div>

      <!-- FUN Staff start -->
      <div class="fun-staff staff-1 block-bg-2 sectionWrapper">
        <div class="container">
            <!-- staff item start -->
            <div class="cell-2 fx" data-animate="fadeInDown" data-animation-delay="200">
                <div class="fun-number"><?php if(isset($fourBox['allusers'])): ?><?php echo e($fourBox['allusers']); ?>+ <?php endif; ?></div>
                <div class="fun-text main-bg"><?php echo e(__('lang.total_members')); ?></div>
                <div class="fun-icon"><i class="fa fa-leaf"></i></div>
            </div>
            <!-- staff item end -->

            <!-- staff item start -->
            <div class="cell-2 fx" data-animate="fadeInDown" data-animation-delay="400">
                <div class="fun-number"><?php if(isset($fourBox['allusers'])): ?><?php echo e($fourBox['providers']); ?>+ <?php endif; ?></div>
                <div class="fun-text main-bg"><?php echo e(__('lang.total_providers')); ?></div>
                <div class="fun-icon"><i class="fa fa-clock-o"></i></div>
            </div>
            <!-- staff item end -->

            <!-- staff item start -->
            <div class="cell-4 fx" data-animate="fadeInDown">
                <div class="fun-title bold"><span><?php echo e(__('lang.our_missions')); ?> </span></div>
            </div>
            <div class="cell-2 fx" data-animate="fadeInDown" data-animation-delay="600">
                <div class="fun-number"><?php if(isset($fourBox['allusers'])): ?><?php echo e($fourBox['employments']); ?>+ <?php endif; ?></div>
                <div class="fun-text main-bg"><?php echo e(__('lang.employments')); ?></div>
                <div class="fun-icon"><i class="fa fa-group"></i></div>
            </div>
            <!-- staff item end -->

            <!-- staff item start -->
            <div class="cell-2 fx" data-animate="fadeInDown" data-animation-delay="800">
                <div class="fun-number"><?php if(isset($fourBox['allusers'])): ?> <?php echo e($fourBox['exportvolume']); ?> + <?php endif; ?></div>
                <div class="fun-text main-bg"><?php echo e(__('lang.e_export_volume')); ?></div>
                <div class="fun-icon"><i class="fa fa-bell"></i></div>
            </div>
            <!-- staff item end -->

        </div><!-- .container end -->
    </div>
    <!-- FUN Staff end -->


</div>
<?php /**PATH C:\Users\ylmzb\Desktop\e-ihracat\resources\views/pages/about-us.blade.php ENDPATH**/ ?>