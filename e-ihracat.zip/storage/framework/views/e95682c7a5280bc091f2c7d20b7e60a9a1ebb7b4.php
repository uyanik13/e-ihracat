﻿<?php
    $references = Helper::findCustomData('References');
?>
<!-- Content Start -->
<div id="contentWrapper">
    <div class="page-title title-1">
        <div class="container">
            <div class="row">
                <div class="cell-12">
                    <h1 class="fx" data-animate="fadeInLeft"><?php echo e(__('lang.our_referances')); ?></h1>
                    <div class="breadcrumbs main-bg fx" data-animate="fadeInUp">
                        <span class="bold"><?php echo e(__('lang.you_are_here')); ?>:</span><a href="#"><?php echo e(__('lang.homepage')); ?></a><span
                            class="line-separate">/</span><a href="#"><?php echo e(__('lang.nav_referances')); ?> </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div id="referanceArea" class="sectionWrapper">
        <div class="container">
            <div class="row">
                <div class="cell-12">
                    <div class="clearfix"></div>
                    <div class="grid-list">
                        <div class="row">
                            <?php if(isset($references)): ?>
                                <?php $__empty_1 = true; $__currentLoopData = $references; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $reference): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <div class="cell-2 fx shop-item" data-animate="fadeInUp">
                                        <div class="item-box">
                                            <h3 class="item-title"><a
                                                    href="<?php echo e($reference['url']); ?>"><?php echo e($reference['name']); ?> </a>
                                            </h3>
                                            <div class="item-img">
                                                <a href="<?php echo e($reference['url']); ?>"><img alt=""
                                                                                     src="<?php echo e($reference['image']); ?>"></a>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <?php endif; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="clearfix"></div>
                </div>
            </div>
        </div>
    </div>

</div>
<!-- Content End -->
<?php /**PATH C:\Users\ylmzb\Desktop\e-ihracat\resources\views/pages/references.blade.php ENDPATH**/ ?>